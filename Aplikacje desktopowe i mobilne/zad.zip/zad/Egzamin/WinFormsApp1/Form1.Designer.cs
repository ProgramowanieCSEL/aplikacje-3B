﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            paczka_radio = new RadioButton();
            list_radio = new RadioButton();
            pocztowka_radio = new RadioButton();
            groupBox2 = new GroupBox();
            label3 = new Label();
            textBox3 = new TextBox();
            label2 = new Label();
            postal_code_input = new TextBox();
            textBox1 = new TextBox();
            label1 = new Label();
            check_price_btn = new Button();
            submit_btn = new Button();
            price_picture = new PictureBox();
            price_info = new Label();
            address_info = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)price_picture).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(paczka_radio);
            groupBox1.Controls.Add(list_radio);
            groupBox1.Controls.Add(pocztowka_radio);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(200, 100);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Rodzaj Przesyłki";
            // 
            // paczka_radio
            // 
            paczka_radio.AutoSize = true;
            paczka_radio.Location = new Point(6, 72);
            paczka_radio.Name = "paczka_radio";
            paczka_radio.Size = new Size(61, 19);
            paczka_radio.TabIndex = 2;
            paczka_radio.TabStop = true;
            paczka_radio.Text = "Paczka";
            paczka_radio.UseVisualStyleBackColor = true;
            // 
            // list_radio
            // 
            list_radio.AutoSize = true;
            list_radio.Location = new Point(6, 47);
            list_radio.Name = "list_radio";
            list_radio.Size = new Size(43, 19);
            list_radio.TabIndex = 1;
            list_radio.TabStop = true;
            list_radio.Text = "List";
            list_radio.UseVisualStyleBackColor = true;
            list_radio.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // pocztowka_radio
            // 
            pocztowka_radio.AutoSize = true;
            pocztowka_radio.Location = new Point(6, 22);
            pocztowka_radio.Name = "pocztowka_radio";
            pocztowka_radio.Size = new Size(82, 19);
            pocztowka_radio.TabIndex = 0;
            pocztowka_radio.TabStop = true;
            pocztowka_radio.Text = "Pocztówka";
            pocztowka_radio.UseVisualStyleBackColor = true;
            pocztowka_radio.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(textBox3);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(postal_code_input);
            groupBox2.Controls.Add(textBox1);
            groupBox2.Controls.Add(label1);
            groupBox2.Location = new Point(330, 12);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(200, 187);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Dane Adresowe";
            groupBox2.Enter += groupBox2_Enter;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(9, 125);
            label3.Name = "label3";
            label3.Size = new Size(43, 15);
            label3.TabIndex = 8;
            label3.Text = "Miasto";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(9, 143);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 23);
            textBox3.TabIndex = 7;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(9, 72);
            label2.Name = "label2";
            label2.Size = new Size(82, 15);
            label2.TabIndex = 6;
            label2.Text = "Kod pocztowy";
            // 
            // postal_code_input
            // 
            postal_code_input.Location = new Point(9, 90);
            postal_code_input.Name = "postal_code_input";
            postal_code_input.Size = new Size(100, 23);
            postal_code_input.TabIndex = 5;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(9, 42);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 24);
            label1.Name = "label1";
            label1.Size = new Size(96, 15);
            label1.TabIndex = 3;
            label1.Text = "Ulica z numerem";
            label1.Click += label1_Click;
            // 
            // check_price_btn
            // 
            check_price_btn.Location = new Point(12, 118);
            check_price_btn.Name = "check_price_btn";
            check_price_btn.Size = new Size(200, 23);
            check_price_btn.TabIndex = 2;
            check_price_btn.Text = "Sprawdź Cenę";
            check_price_btn.UseVisualStyleBackColor = true;
            check_price_btn.Click += check_price_btn_Click;
            // 
            // submit_btn
            // 
            submit_btn.Location = new Point(12, 264);
            submit_btn.Name = "submit_btn";
            submit_btn.Size = new Size(518, 23);
            submit_btn.TabIndex = 3;
            submit_btn.Text = "Zatwierdź";
            submit_btn.UseVisualStyleBackColor = true;
            submit_btn.Click += submit_btn_Click;
            // 
            // price_picture
            // 
            price_picture.Image = Properties.Resources.pocztowka;
            price_picture.Location = new Point(12, 155);
            price_picture.Name = "price_picture";
            price_picture.Size = new Size(101, 63);
            price_picture.TabIndex = 4;
            price_picture.TabStop = false;
            // 
            // price_info
            // 
            price_info.AutoSize = true;
            price_info.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            price_info.Location = new Point(134, 155);
            price_info.Name = "price_info";
            price_info.Size = new Size(0, 30);
            price_info.TabIndex = 5;
            price_info.Visible = false;
            // 
            // address_info
            // 
            address_info.AutoSize = true;
            address_info.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            address_info.Location = new Point(12, 221);
            address_info.Name = "address_info";
            address_info.Size = new Size(0, 30);
            address_info.TabIndex = 6;
            address_info.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(address_info);
            Controls.Add(price_info);
            Controls.Add(price_picture);
            Controls.Add(submit_btn);
            Controls.Add(check_price_btn);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)price_picture).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private RadioButton paczka_radio;
        private RadioButton list_radio;
        private RadioButton pocztowka_radio;
        private Label label1;
        private Button check_price_btn;
        private Label label2;
        private TextBox postal_code_input;
        private TextBox textBox1;
        private Label label3;
        private TextBox textBox3;
        private Button submit_btn;
        private PictureBox price_picture;
        private Label price_info;
        private Label address_info;
    }
}