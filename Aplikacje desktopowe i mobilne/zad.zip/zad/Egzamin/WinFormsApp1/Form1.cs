namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void check_price_btn_Click(object sender, EventArgs e)
        {
            if ((pocztowka_radio.Checked || list_radio.Checked || paczka_radio.Checked) && price_info.Visible != true)
            {
                price_info.Visible = true;
            }
            if (pocztowka_radio.Checked)
            {
                price_picture.Image = Properties.Resources.pocztowka;
                price_info.Text = "Cena: 1z�";
            }
            else if (list_radio.Checked)
            {
                price_picture.Image = Properties.Resources.list;
                price_info.Text = "Cena: 1.5z�";
            }
            else if (paczka_radio.Checked)
            {
                price_picture.Image = Properties.Resources.paczka;
                price_info.Text = "Cena: 10z�";
            }
        }

        private void submit_btn_Click(object sender, EventArgs e)
        {
            address_info.Visible = true;
            if (postal_code_input.TextLength == 5)
            {
                address_info.Text = "Dane przesy�ki zosta�y wprowadzone";
            }
            else
            {
                address_info.Text = "Nieprawid�owa liczba cyfr w kodzie pocztowym";
            }
        }
    }
}